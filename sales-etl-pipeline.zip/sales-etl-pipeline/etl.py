import os
import time
import logging
import pandas as pd
from sqlalchemy import create_engine, text
from datetime import datetime

os.makedirs("logs", exist_ok=True)
log_filename = f"logs/pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

RAW_DATA_PATH = "superstore_sales.csv"
CLEAN_DATA_PATH = "superstore_sales_clean.csv"
DB_URL = "postgresql://postgres:1234@localhost:5432/sales_db"

REQUIRED_COLUMNS = [
    "Order ID", "Order Date", "Ship Date", "Ship Mode",
    "Customer ID", "Customer Name", "Segment", "Country",
    "City", "State", "Postal Code", "Region",
    "Product ID", "Category", "Sub-Category", "Product Name",
    "Sales", "Quantity", "Discount", "Profit"
]


def extract(path):
    logger.info(f"Extracting data from: {path}")
    if not os.path.exists(path):
        raise FileNotFoundError(f"CSV file not found: {path}")
    df = pd.read_csv(path, encoding="latin-1")
    logger.info(f"Extracted {len(df)} rows, {len(df.columns)} columns.")
    return df


def validate(df):
    logger.info("Starting validation...")
    initial_count = len(df)

    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing columns: {missing_cols}")

    critical = ["Order ID", "Sales", "Quantity", "Profit", "Order Date"]
    null_mask = df[critical].isnull().any(axis=1)
    if null_mask.sum() > 0:
        logger.warning(f"Dropped {null_mask.sum()} rows with nulls.")
        df = df[~null_mask]

    dup_count = df.duplicated(subset=["Order ID", "Product ID"]).sum()
    if dup_count > 0:
        logger.warning(f"Dropped {dup_count} duplicate rows.")
        df = df.drop_duplicates(subset=["Order ID", "Product ID"])

    for col in ["Sales", "Quantity", "Discount", "Profit"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    bad_num = df[["Sales", "Quantity", "Discount", "Profit"]].isnull().any(axis=1)
    if bad_num.sum() > 0:
        logger.warning(f"Dropped {bad_num.sum()} rows with bad numeric values.")
        df = df[~bad_num]

    neg = (df["Sales"] < 0).sum()
    if neg > 0:
        logger.warning(f"Dropped {neg} rows with negative Sales.")
        df = df[df["Sales"] >= 0]

    logger.info(f"Validation done. {len(df)} rows passed, {initial_count - len(df)} skipped.")
    return df


def transform(df):
    logger.info("Transforming data...")
    df.columns = [c.strip().lower().replace(" ", "_").replace("-", "_") for c in df.columns]
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    df["ship_date"] = pd.to_datetime(df["ship_date"], errors="coerce")
    df["shipping_days"] = (df["ship_date"] - df["order_date"]).dt.days
    df["profit_margin"] = (df["profit"] / df["sales"]).round(4)
    df["order_year"] = df["order_date"].dt.year
    df["order_month"] = df["order_date"].dt.month
    for col in ["customer_name", "city", "state", "country", "category"]:
        if col in df.columns:
            df[col] = df[col].str.strip().str.title()
    logger.info(f"Transform done. Shape: {df.shape}")
    return df


def save_clean(df, path):
    df.to_csv(path, index=False)
    logger.info(f"Clean CSV saved: {path}")


def load(df, db_url):
    logger.info("Connecting to PostgreSQL...")
    try:
        engine = create_engine(db_url)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info("Connected!")
    except Exception as e:
        raise ConnectionError(f"DB connection failed: {e}")
    df.to_sql("sales_data", engine, if_exists="replace", index=False)
    logger.info(f"Loaded {len(df)} rows into sales_data table.")


def summary_report(raw_count, clean_count, start_time):
    skipped = raw_count - clean_count
    elapsed = round(time.time() - start_time, 2)
    print(f"""
╔══════════════════════════════════╗
║      PIPELINE SUMMARY REPORT     ║
╠══════════════════════════════════╣
║  Rows Extracted : {raw_count:<14} ║
║  Rows Loaded    : {clean_count:<14} ║
║  Rows Skipped   : {skipped:<14} ║
║  Time Taken     : {elapsed}s           ║
╚══════════════════════════════════╝
""")


def main():
    start_time = time.time()
    logger.info("===== Sales ETL Pipeline Started =====")
    try:
        df_raw = extract(RAW_DATA_PATH)
        raw_count = len(df_raw)
        df_valid = validate(df_raw)
        df_clean = transform(df_valid)
        save_clean(df_clean, CLEAN_DATA_PATH)
        load(df_clean, DB_URL)
        summary_report(raw_count, len(df_clean), start_time)
        logger.info("===== Pipeline Finished Successfully =====")
    except FileNotFoundError as e:
        logger.error(f"FILE ERROR: {e}")
    except ValueError as e:
        logger.error(f"VALIDATION ERROR: {e}")
    except ConnectionError as e:
        logger.error(f"DB ERROR: {e}")
    except Exception as e:
        logger.error(f"UNEXPECTED ERROR: {e}")


if __name__ == "__main__":
    main()