# Sales Data ETL Pipeline

A production-style ETL (Extract, Transform, Load) pipeline that processes Superstore Sales data from Kaggle, validates data quality, and loads it into PostgreSQL.

---

## Architecture

```
Raw CSV (Kaggle)
      │
      ▼
  [EXTRACT]
  Read CSV with pandas
      │
      ▼
  [VALIDATE]
  - Check required columns
  - Remove nulls in critical fields
  - Remove duplicates
  - Fix invalid numeric values
  - Drop negative sales
      │
      ▼
  [TRANSFORM]
  - Normalize column names
  - Parse date columns
  - Add derived columns (shipping_days, profit_margin, order_year, order_month)
  - Clean string fields
      │
      ▼
  [SAVE CLEANED CSV]
  superstore_sales_clean.csv
      │
      ▼
  [LOAD]
  PostgreSQL → sales_data table
      │
      ▼
  [SUMMARY REPORT]
  Rows processed, skipped, time taken
```

---

## Folder Structure

```
sales-etl-pipeline/
├── logs/                          ← Auto-generated log files (one per run)
├── etl.py                         ← Main pipeline script
├── gitignore                      ← Git ignore rules
├── README.md                      ← Project documentation
├── requirements.txt               ← Python dependencies
├── superstore_sales.csv           ← Raw dataset from Kaggle
└── superstore_sales_clean.csv     ← Auto-generated cleaned dataset
```

---

## Dataset

Download the **Superstore Sales Dataset** from Kaggle:
- URL: https://www.kaggle.com/datasets/vivek468/superstore-dataset-final
- File: `Sample - Superstore.csv`
- Rename it to `superstore_sales.csv` and place it in the root project folder

---

## Setup & How to Run

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/sales-etl-pipeline.git
cd sales-etl-pipeline
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set up PostgreSQL
- Install PostgreSQL locally (free): https://www.postgresql.org/download/
- Open terminal and create the database:
```bash
psql -U postgres
CREATE DATABASE sales_db;
\q
```
- Update your password in `etl.py` line 19:
```python
DB_URL = "postgresql://postgres:YOUR_PASSWORD@localhost:5432/sales_db"
```

### 4. Place dataset
Rename downloaded file to `superstore_sales.csv` and place it in the project root folder.

### 5. Run the pipeline
```bash
python etl.py
```

---

## Pipeline Results

- **Rows Extracted:** 9,994
- **Rows Loaded:** 9,986
- **Rows Skipped:** 8 (duplicates removed)
- **Time Taken:** ~7 seconds

---

## Features

| Feature | Detail |
|---|---|
| Data Validation | Null checks, duplicate removal, type validation, negative value checks |
| Logging | Every run creates a timestamped log file in `/logs` |
| Error Handling | Graceful failure with clear error messages |
| Summary Report | Rows processed, skipped, and time taken printed after each run |
| Derived Columns | shipping_days, profit_margin, order_year, order_month |

---

## Interview Topics Covered

- **ETL concepts**: Extract, Transform, Load pipeline design
- **Data quality**: Validation before loading, fail-safe error handling
- **Logging**: Python logging module with file + console output
- **SQL + ORM**: SQLAlchemy for PostgreSQL integration
- **Pandas**: Data manipulation and transformation

---

## Tech Stack

- Python 3.10+
- Pandas
- SQLAlchemy
- PostgreSQL
- Python logging module
- Kaggle (dataset source)